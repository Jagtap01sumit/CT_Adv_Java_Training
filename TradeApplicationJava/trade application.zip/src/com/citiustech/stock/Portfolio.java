package com.citiustech.stock;

import java.util.Map;

public class Portfolio {
	
		public static void myPortfolio(User_Management bs) {
			Map<String,Integer> map = bs.showPortfolio();
			for(String stock:map.keySet()) {
				System.out.println("hello");
				System.out.println(stock +"|"+ map.get(stock));
			}
		}
}
