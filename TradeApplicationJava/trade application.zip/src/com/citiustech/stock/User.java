package com.citiustech.stock;

import java.util.HashMap;
import java.util.Map;

class User extends User_Management{

	
	 public User(String email, String name) {
	        super(email, name);
	  }

	 
	
	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllUsers() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(int id) {
		// TODO Auto-generated method stub
		
	}
	
	public void buyStock() {
		portfolio.put("newstock", 19000);
	}

}
   