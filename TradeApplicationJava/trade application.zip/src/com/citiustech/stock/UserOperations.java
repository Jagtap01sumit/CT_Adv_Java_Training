package com.citiustech.stock;

public interface UserOperations   {
	
	public  void deleteUser(int id);
	public  void getAllUsers();
	public void updateUser(int id);
}
