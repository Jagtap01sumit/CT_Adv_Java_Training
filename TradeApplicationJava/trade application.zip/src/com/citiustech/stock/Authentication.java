package com.citiustech.stock;

import com.citiustech.db.UserDB;

public  class Authentication {
		private Authentication() {
			
		}
		public static User createNewUser(String email,String name) {
			User createNewUser = new User(email,name);
			
			UserDB db=new UserDB();
			db.saveUser(createNewUser);
			
			return createNewUser;
		}
		public static void getUserInfo(User_Management user) {
			System.out.println(user.toString());
		}
	
		
		
		
}
