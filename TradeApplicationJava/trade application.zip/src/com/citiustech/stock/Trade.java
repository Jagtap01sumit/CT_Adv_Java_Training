package com.citiustech.stock;

import java.util.Date;

 class Trade extends BaseEntity implements TradeOperations {
	 public static int nextId;
   
    private User user;
    private Stock stock;
    private int quantity;
    private String tradeType;
    private Date timeStamp;

    Trade( User user, Stock stock, int quantity, String tradeType) {
		super();

        this.id = nextId++;
        this.user = user;
        this.stock = stock;
        this.quantity = quantity;
        this.tradeType = tradeType;
        this.timeStamp = new Date(); 
    }

    @Override
    public void buyStock() {
//        System.out.println("Buying " + quantity + " shares of " + stock.getStockName());
    }

    @Override
    public void sellStock() {
//        System.out.println("Selling " + quantity + " shares of " + stock.getStockName());
    }

    @Override
    public void history() {
//        System.out.println("Trade History: " + tradeType + " " + quantity + " shares of " + stock.getStockName() + " on " + timeStamp);
    }

    @Override
    public void portfolioValue() {
//        double portfolioValue = stock.getStockPrice() * quantity;
//        System.out.println("Portfolio Value: $" + portfolioValue);
    }
    
    public String toString() {
    	return "Trade Id:"+id+"| User Email :" + user.email+"| "+user.name +"| Stock"+stock.getCompanyName()+ "| quantity"+quantity +"| trade type"+ tradeType+ "Time"+timeStamp;
    }
}