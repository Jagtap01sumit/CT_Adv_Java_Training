package com.citiustech.stock;

public interface TradeOperations {
	public void buyStock();
	public void sellStock();
	public void history();
	public void portfolioValue();
}
