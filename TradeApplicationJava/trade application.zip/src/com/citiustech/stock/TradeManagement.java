package com.citiustech.stock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TradeManagement {
	private TradeManagement() {} 
	static List<Trade> tradeList =new ArrayList<>();
	
    public static Trade trade( User_Management user, Stock stock, int quantity, String tradeType) {
    	
    		Trade trd = new  Trade((User) user,stock,quantity,tradeType);
			tradeList.add(trd);
			return trd;		
    
    }
//    private static void saveTradeToDB(Trade trade) {
//        
//
//        try {
//            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
//            pstmt = conn.prepareStatement("INSERT INTO trade_history (user_id, stock, quantity, trade_type) VALUES (?, ?, ?, ?)");
//            pstmt.setInt(1, trade.getUser().getId());
//            pstmt.setString(2, trade.getStock().getSymbol());
//            pstmt.setInt(3, trade.getQuantity());
//            pstmt.setString(4, trade.getTradeType());
//            pstmt.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (pstmt != null) {
//                    pstmt.close();
//                }
//                if (conn != null) {
//                    conn.close();
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    
    public static void history(User_Management user){
    	for(Trade tr:tradeList) {
    		System.out.println(tr.toString());
    	}
    }
//    
//    private static final String DB_URL = "jdbc:mysql://localhost:3306/user";
//    private static final String DB_USERNAME = "root";
//    private static final String DB_PASSWORD = "root";
//
//    public static List<Trade> getTradeHistoryFromDB(User_Management user) {
//        List<Trade> trades = new ArrayList<>();
//        Connection conn = null;
//        PreparedStatement pstmt = null;
//        ResultSet rs = null;
//
//        try {
//            conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//            pstmt = conn.prepareStatement("SELECT * FROM trade_history WHERE user_id = ?");
//            pstmt.setInt(1, user.getId());
//            rs = pstmt.executeQuery();
//
//            while (rs.next()) {
//                Trade trade = new Trade(user, new Stock(rs.getString("stock")), rs.getInt("quantity"), rs.getString("trade_type"));
//                trades.add(trade);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (rs != null) {
//                    rs.close();
//                }
//                if (pstmt != null) {
//                    pstmt.close();
//                }
//                if (conn != null) {
//                    conn.close();
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//
//        return trades;
//    }
}
