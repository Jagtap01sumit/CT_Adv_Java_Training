package com.citiustech.stock;

public class Stock extends BaseEntity {
	public static int nextId;
	  private int id;
	    private String symbol;
	    private String companyName;
	    private double pricePerShare;
	    private int quantity;
	    // Constructor
	    public Stock( String symbol, String companyName, double pricePerShare, int quantity) {
			super();

	    	this.id=nextId++;
	        this.id = id;
	        this.symbol = symbol;
	        this.companyName = companyName;
	        this.pricePerShare = pricePerShare;
	        this.quantity=quantity;
	    }

	    public int getStockId() {
	        return id;
	    }

	    public void setStockId(int stockId) {
	        this.id = stockId;
	    }

	    public String getSymbol() {
	        return symbol;
	    }

	    public void setSymbol(String symbol) {
	        this.symbol = symbol;
	    }

	    public String getCompanyName() {
	        return companyName;
	    }

	    public void setCompanyName(String companyName) {
	        this.companyName = companyName;
	    }

	    public double getPricePerShare() {
	        return pricePerShare;
	    }
	    public int getQuantity() {
	    	return quantity;
	    }
	    public void setPricePerShare(double pricePerShare) {
	        this.pricePerShare = pricePerShare;
	    }
	
}
