package com.citiustech.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.citiustech.exceptions.UserAlreadyExistException;
import com.citiustech.stock.User_Management;

public class UserDB {
    private Connection connection;

    public UserDB() {
        try {
            connection  = DriverManager.getConnection("jdbc:mysql://localhost:3306/stock_application", "root", "root");
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        }
    }

    public void saveUser(User_Management user) throws UserAlreadyExistException {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE email = ?");
            statement.setString(1, user.email());
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                throw new UserAlreadyExistException("User with email " + user.email() + " already exists");
            }

            statement = connection.prepareStatement("INSERT INTO users (name, email) VALUES (?, ?)");
            statement.setString(1, user.name());
            statement.setString(2, user.email());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error saving user: " + e.getMessage());
        }
    }
    
}