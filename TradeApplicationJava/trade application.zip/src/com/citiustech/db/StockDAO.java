package com.citiustech.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.stock.Stock;

public class StockDAO {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/stock_application";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "root";

  

    
    public List<Stock> getStocks() {
        List<Stock> stocks = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Stocks")) {

            while (rs.next()) {
                Stock stock = new Stock(
                        rs.getString(2),
                        rs.getString(4),
                        rs.getDouble(3),
                        
                        rs.getInt(5)
                );
               
               
                stocks.add(stock);
//                System.out.printf("%d\t%s\t%.2f\t%s\t%d%n",rs.getInt(1),rs.getString(2),rs.getDouble(3), rs.getString(4),rs.getInt(5));
            }
        } catch (SQLException e) {
            System.out.println("Error getting stocks: " + e);
        }

        return stocks;
    }
    
    
    
//    public void insertStock(Stock stock) {
//        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Stocks (symbol, companyName, pricePerShare) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
//
//            stmt.setString(1, stock.getSymbol());
//            stmt.setString(2, stock.getCompanyName());
//            stmt.setDouble(3, stock.getPricePerShare());
//
//            stmt.executeUpdate();
//
//            try (ResultSet rs = stmt.getGeneratedKeys()) {
//                if (rs.next()) {
//                    stock.setStockId(rs.getInt(1));
//                }
//            }
//        } catch (SQLException e) {
//            System.out.println("Error inserting stock: " + e.getMessage());
//        }
//    }

}