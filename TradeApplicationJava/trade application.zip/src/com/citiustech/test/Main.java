package com.citiustech.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citiustech.db.StockDAO;
import com.citiustech.stock.Authentication;
import com.citiustech.stock.Portfolio;
import com.citiustech.stock.Stock;
import com.citiustech.stock.TradeManagement;
import com.citiustech.stock.UserOperations;
import com.citiustech.stock.User_Management;

public class Main {
    public static void main(String[] args) {
       
        StockDAO stockDAO = new StockDAO();
        Scanner scanner = new Scanner(System.in);
        User_Management user = null;

        do {
            System.out.println("1. Create User");
            System.out.println("2. View Stocks");
            System.out.println("3. Buy Stock");
            System.out.println("4. Sell Stock");
            System.out.println("5. View Portfolio");
            System.out.println("6. View Trade History");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter your email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter your name: ");
                    String name = scanner.nextLine();
                    try {
                    user = Authentication.createNewUser(email, name);
                    System.out.println("User created successfully!");
                    }catch(Exception e) {
                    	System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    if (user == null) {
                        System.out.println("Please create a user first!");
                        break;
                    }
                    List<Stock> dbStocks = stockDAO.getStocks();

                    for (Stock stock : dbStocks) {
                        System.out.printf("%d, \t%s, \t%.2f, \t,%s, \t%d\n", stock.getStockId(), stock.getSymbol(), stock.getPricePerShare(), stock.getCompanyName(),stock.getQuantity());
                    }
                    break;
                case 3:
                    if (user == null) {
                        System.out.println("Please create a user first!");
                        break;
                    }
                    System.out.print("Enter the symbol of the stock you want to buy: ");
                    String buySymbol = scanner.nextLine();
                    Stock buyStock = getStockBySymbol(stockDAO, buySymbol);

                    if (buyStock != null) {
                        System.out.print("Enter the quantity you want to buy: ");
                        int buyQuantity = scanner.nextInt();
                        scanner.nextLine(); 

                        TradeManagement.trade(user, buyStock, buyQuantity, "BUY");
                    } else {
                        System.out.println("Stock not found.");
                    }
                    break;
                case 4:
                    if (user == null) {
                        System.out.println("Please create a user first!");
                        break;
                    }
                    System.out.print("Enter the symbol of the stock you want to sell: ");
                    String sellSymbol = scanner.nextLine();
                    Stock sellStock = getStockBySymbol(stockDAO, sellSymbol);

                    if (sellStock != null) {
                        System.out.print("Enter the quantity you want to sell: ");
                        int sellQuantity = scanner.nextInt();
                        scanner.nextLine(); 

                        TradeManagement.trade(user, sellStock, sellQuantity, "SELL");
                    } else {
                        System.out.println("Stock not found.");
                    }
                    break;
                case 5:
                    if (user == null) {
                        System.out.println("Please create a user first!");
                        break;
                    }
                    Portfolio.myPortfolio(user);
                    break;
                case 6:
                    if (user == null) {
                        System.out.println("Please create a user first!");
                        break;
                    }
                    TradeManagement.history(user);
                    break;
                case 7:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (true);
    }

    private static Stock getStockBySymbol(StockDAO stockDAO, String symbol) {
        List<Stock> dbStocks = stockDAO.getStocks();

        for (Stock stock : dbStocks) {
            if (stock.getSymbol().equals(symbol)) {
                return stock;
            }
        }

        return null;
    }
}